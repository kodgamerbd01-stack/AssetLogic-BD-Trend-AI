
import React, { useState, useCallback } from 'react';
import { detectTrendsAndGenerateIdeas } from './geminiService';
import { TrendAnalysis, AppStatus, VideoIdea } from './types';
import { 
  MagnifyingGlassIcon, 
  RocketLaunchIcon, 
  ExclamationCircleIcon,
  VideoCameraIcon,
  ChartBarIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [analysis, setAnalysis] = useState<TrendAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startScanning = useCallback(async () => {
    setStatus(AppStatus.SCANNING);
    setError(null);
    try {
      // Step 1: Scanning/Search (Simulated delay for UX)
      await new Promise(r => setTimeout(r, 1500));
      setStatus(AppStatus.ANALYZING);
      
      const data = await detectTrendsAndGenerateIdeas();
      setAnalysis(data);
      setStatus(AppStatus.COMPLETED);
    } catch (err) {
      setError("Trend detection failed. Please try again.");
      setStatus(AppStatus.ERROR);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8">
      {/* Header */}
      <header className="w-full max-w-5xl flex flex-col md:flex-row justify-between items-center mb-12 gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-500 p-2 rounded-lg shadow-lg shadow-emerald-500/20">
            <RocketLaunchIcon className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-400">
              AssetLogic BD
            </h1>
            <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Autonomous Trend AI</p>
          </div>
        </div>
        
        {status === AppStatus.IDLE || status === AppStatus.COMPLETED || status === AppStatus.ERROR ? (
          <button
            onClick={startScanning}
            className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 transition-all rounded-full font-bold shadow-lg shadow-emerald-900/40 text-sm md:text-base group"
          >
            {status === AppStatus.COMPLETED ? (
              <><ArrowPathIcon className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" /> Refresh Trends</>
            ) : (
              <><MagnifyingGlassIcon className="w-5 h-5" /> Start Global Scan</>
            )}
          </button>
        ) : null}
      </header>

      {/* Main Content Area */}
      <main className="w-full max-w-5xl flex-1 flex flex-col">
        {status === AppStatus.IDLE && (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-20 space-y-6">
            <div className="relative">
              <div className="absolute inset-0 bg-emerald-500 blur-3xl opacity-20 animate-pulse"></div>
              <ChartBarIcon className="w-32 h-32 text-slate-700 relative z-10" />
            </div>
            <div className="max-w-md">
              <h2 className="text-3xl font-bold mb-4">Autonomous Finance Intelligence</h2>
              <p className="text-slate-400">
                Click the button above to start scanning Bangladesh's current business landscape. 
                Our AI will identify the top trend and generate viral video scripts.
              </p>
            </div>
          </div>
        )}

        {(status === AppStatus.SCANNING || status === AppStatus.ANALYZING) && (
          <div className="flex-1 flex flex-col items-center justify-center py-20 space-y-8">
            <div className="w-48 h-48 relative flex items-center justify-center">
              <div className="absolute inset-0 border-4 border-emerald-500/20 rounded-full"></div>
              <div className="absolute inset-0 border-t-4 border-emerald-500 rounded-full animate-spin"></div>
              <MagnifyingGlassIcon className="w-16 h-16 text-emerald-500 animate-pulse" />
            </div>
            <div className="text-center">
              <h2 className="text-2xl font-bold text-emerald-400 mb-2">
                {status === AppStatus.SCANNING ? "Scanning Bangladesh Web Signals..." : "Analyzing Data with Gemini Pro..."}
              </h2>
              <p className="text-slate-500 max-w-sm mx-auto">
                Processing recent news headlines, search volume spikes, and economic reports for the target audience (16-35).
              </p>
            </div>
          </div>
        )}

        {status === AppStatus.ERROR && (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-20 space-y-4">
            <ExclamationCircleIcon className="w-16 h-16 text-red-500" />
            <h2 className="text-2xl font-bold">{error}</h2>
            <button 
              onClick={startScanning}
              className="px-6 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg"
            >
              Try Again
            </button>
          </div>
        )}

        {status === AppStatus.COMPLETED && analysis && (
          <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* Trend Highlight */}
            <section className="bg-slate-800/50 border border-slate-700 rounded-3xl p-8 md:p-12 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <ChartBarIcon className="w-32 h-32" />
              </div>
              <div className="relative z-10 max-w-3xl">
                <div className="inline-block px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-bold rounded-full uppercase tracking-widest mb-4">
                  Top Trending Topic
                </div>
                <h2 className="text-4xl md:text-5xl font-black mb-6 leading-tight">
                  {analysis.trendingTopic}
                </h2>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Why It's Trending</h3>
                    <p className="text-xl text-slate-200 leading-relaxed font-['Hind_Siliguri']">
                      {analysis.whyTrending}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Why People Should Care</h3>
                    <p className="text-xl text-emerald-100 font-semibold leading-relaxed font-['Hind_Siliguri']">
                      {analysis.whyCare}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Video Ideas */}
            <section>
              <div className="flex items-center gap-3 mb-8">
                <VideoCameraIcon className="w-6 h-6 text-emerald-500" />
                <h2 className="text-2xl font-bold">Short-Video Content Ideas</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {analysis.videoIdeas.map((idea, index) => (
                  <VideoIdeaCard key={idea.id} idea={idea} index={index} />
                ))}
              </div>
            </section>
          </div>
        )}
      </main>

      <footer className="w-full max-w-5xl py-12 mt-12 border-t border-slate-800 text-center text-slate-500 text-sm">
        <p>© {new Date().getFullYear()} AssetLogic BD Trend-Detection AI. Data sourced autonomously via Gemini.</p>
      </footer>
    </div>
  );
};

interface VideoIdeaCardProps {
  idea: VideoIdea;
  index: number;
}

const VideoIdeaCard: React.FC<VideoIdeaCardProps> = ({ idea, index }) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col h-full hover:border-emerald-500/50 transition-all duration-300 group shadow-xl">
      <div className="flex justify-between items-start mb-6">
        <span className="text-4xl font-black text-slate-800 group-hover:text-emerald-500/10 transition-colors">
          0{index + 1}
        </span>
        <div className="px-3 py-1 bg-slate-800 text-slate-400 text-[10px] font-bold rounded-lg uppercase">
          {idea.duration}
        </div>
      </div>
      
      <div className="flex-1 space-y-4">
        <div>
          <span className="text-emerald-500 text-xs font-bold uppercase tracking-widest block mb-1">Hook</span>
          <p className="text-lg font-bold text-white font-['Hind_Siliguri'] leading-tight line-clamp-2">
            "{idea.hook}"
          </p>
        </div>

        <div>
          <span className="text-slate-500 text-xs font-bold uppercase tracking-widest block mb-1">Topic</span>
          <p className="text-slate-300 font-['Hind_Siliguri'] font-medium">
            {idea.topic}
          </p>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <p className="text-sm text-slate-400 mb-4 font-['Hind_Siliguri'] italic">
            <span className="text-emerald-500/80 font-bold not-italic mr-1">Core Question:</span>
            {idea.coreQuestion}
          </p>
          
          <div className="bg-slate-800/40 p-3 rounded-xl">
             <span className="text-slate-500 text-[10px] font-bold uppercase tracking-widest block mb-1">Visual Direction</span>
             <p className="text-xs text-slate-400 leading-relaxed font-['Hind_Siliguri']">
               {idea.visualIdea}
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
