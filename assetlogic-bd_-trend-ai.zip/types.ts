
export interface VideoIdea {
  id: number;
  hook: string;
  topic: string;
  coreQuestion: string;
  duration: string;
  visualIdea: string;
}

export interface TrendAnalysis {
  trendingTopic: string;
  whyTrending: string;
  whyCare: string;
  videoIdeas: VideoIdea[];
}

export enum AppStatus {
  IDLE = 'IDLE',
  SCANNING = 'SCANNING',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}
