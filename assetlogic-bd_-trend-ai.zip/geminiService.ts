
import { GoogleGenAI, Type } from "@google/genai";
import { TrendAnalysis } from "./types";

const MODEL_NAME = "gemini-3-pro-preview";

export const detectTrendsAndGenerateIdeas = async (): Promise<TrendAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are an autonomous trend-detection AI for Bangladesh.
    Current Task: Identify the SINGLE most relevant Business & Finance trending topic in Bangladesh from the last 48 hours.
    
    Research using Google Search:
    - Search for 'Bangladesh business news last 24 hours'
    - Search for 'Bangladesh stock market latest'
    - Search for 'Bangladesh inflation and commodity prices'
    - Search for 'Bangladesh banking sector trends'
    
    Based on your search:
    1. Select the SINGLE most impactful topic.
    2. Explain in simple Bangla why it is trending.
    3. Explain in emotional Bangla why a 16-35 year old Bangladeshi should care.
    4. Generate EXACTLY 5 short-video ideas inspired by 'The Asset Logic' style.
    
    Rules for Video Ideas:
    - Language: Simple spoken Bangla/Banglish.
    - Tone: Friendly, eye-opening.
    - No complex jargon.
    
    Output MUST be in the following JSON structure:
    {
      "trendingTopic": "...",
      "whyTrending": "...",
      "whyCare": "...",
      "videoIdeas": [
        {
          "id": 1,
          "hook": "max 12 words Bangla hook",
          "topic": "Curiosity driven Bangla title",
          "coreQuestion": "What the viewer will learn",
          "duration": "30-60 sec",
          "visualIdea": "Simple visual concept"
        },
        ... (total 5)
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            trendingTopic: { type: Type.STRING },
            whyTrending: { type: Type.STRING },
            whyCare: { type: Type.STRING },
            videoIdeas: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.NUMBER },
                  hook: { type: Type.STRING },
                  topic: { type: Type.STRING },
                  coreQuestion: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  visualIdea: { type: Type.STRING }
                },
                required: ["id", "hook", "topic", "coreQuestion", "duration", "visualIdea"]
              }
            }
          },
          required: ["trendingTopic", "whyTrending", "whyCare", "videoIdeas"]
        }
      }
    });

    const result = JSON.parse(response.text);
    return result as TrendAnalysis;
  } catch (error) {
    console.error("Error detecting trends:", error);
    throw error;
  }
};
